# Writeups

个人 CTF 解题报告仓库。按 `年份/赛事/分类-题目` 三级归档，所有题目统一使用 [templates/writeup-template.md](templates/writeup-template.md) 模板撰写。

## 目录

### 2025
<!-- 新增赛事在此追加一行：| 赛事名 | 日期 | 名次 | 链接 | -->

### 2024
| 赛事 | 日期 | 名次 | Writeup |
| --- | --- | --- | --- |
| 0CTF Quals | 2024-03 | - | [进入](2024/0ctf-quals) |

## 分类图例

| 缩写 | 方向 | 缩写 | 方向 |
| --- | --- | --- | --- |
| `web` | Web 安全 | `pwn` | 二进制利用 |
| `rev` | 逆向工程 | `crypto` | 密码学 |
| `misc` | 杂项 | `forensics` | 取证 |
| `osint` | 开源情报 | `blockchain` | 区块链 |

## 使用方式

```bash
# 新建一道题
cp templates/writeup-template.md 2025/赛事名/web-题目名/README.md

# 写完后提交
git add 2025/赛事名/
git commit -m "writeup: 2025/赛事名/web-题目名"
git push
```

## 规范

1. **目录名**：`分类-题目名`，英文小写、连字符分隔，如 `web-ssrf-me`
2. **每题一目录**：正文 `README.md` + 脚本 + 截图，全部内聚在同目录
3. **提交粒度**：一道题解完或一个思路验证通过即 commit，不攒批
4. **公开前脱敏**：flag、内部地址、密钥、队友信息必须清除
5. **截图放 `assets/` 或题目目录下**，并在文档中引用相对路径
