#!/usr/bin/env bash
# 一键新建 Writeup：bash new-writeup.sh 2025 "defcon-ctf" web "ssrf-me"
# 用法：new-writeup.sh <年份> <赛事名> <分类> <题目名>

set -e

YEAR="${1:?年份必填，如 2025}"
EVENT="${2:?赛事名必填，如 defcon-ctf}"
CAT="${3:?分类必填，如 web}"
NAME="${4:?题目名必填，如 ssrf-me}"

DIR="${YEAR}/${EVENT}/${CAT}-${NAME}"
TEMPLATE="$(dirname "$0")/../templates/writeup-template.md"

mkdir -p "${DIR}"
cp "${TEMPLATE}" "${DIR}/README.md"

cat > "${DIR}/.meta" <<EOF
YEAR=${YEAR}
EVENT=${EVENT}
CATEGORY=${CAT}
NAME=${NAME}
CREATED=$(date '+%Y-%m-%d %H:%M')
EOF

echo "已创建 ${DIR}/README.md"
echo "下一步：编辑后提交  git add ${DIR} && git commit -m \"wip: ${EVENT}/${CAT}-${NAME} 新建\""
