# 提交信息规范

统一格式，便于日后用 `git log --grep` 检索：

```
<type>: <赛事>/<题目> <简述>
```

## type 类型

| 类型 | 用途 |
| --- | --- |
| `writeup` | 新增或完成一道题的 Writeup |
| `wip` | 解题进行中，未完稿 |
| `fix` | 修正已提交 Writeup 的错误 |
| `add` | 补充附件、截图、脚本 |
| `refactor` | 重整目录结构或模板 |
| `meta` | 修改 .gitignore、模板、说明文档 |

## 示例

```
writeup: 0ctf-quals/web-ssrf-me 完成解题
wip: 0ctf-quals/pwn-babyheap 分析堆布局中
fix: 0ctf-quals/web-login 修正堆喷偏移
add: 0ctf-quals/crypto-rsa 补充 exp.py 与截图
```

## 检索技巧

```bash
# 找某道题
git log --all --grep="web-ssrf-me"

# 看某赛事改过哪些
git log --all --grep="0ctf-quals" --oneline

# 看某个分类的演进
git log --all --grep="pwn" --oneline
```
